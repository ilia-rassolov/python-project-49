from brain_games.games import progression
from brain_games.games import logic


def main():
    logic.game_make(progression)


if __name__ == '__main__':
    main()
