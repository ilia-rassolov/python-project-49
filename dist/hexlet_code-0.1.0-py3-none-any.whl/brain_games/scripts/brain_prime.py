from brain_games.games import prime
from brain_games.games import logic


def main():
    logic.game_make(prime)


if __name__ == '__main__':
    main()
