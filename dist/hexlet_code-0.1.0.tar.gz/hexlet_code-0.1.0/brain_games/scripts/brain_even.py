#!/usr/bin/env python3

from brain_games.even import even_numbers


def main():
    print("Welcome to the Brain Games!")
    even_numbers()


if __name__ == '__main__':
    main()
