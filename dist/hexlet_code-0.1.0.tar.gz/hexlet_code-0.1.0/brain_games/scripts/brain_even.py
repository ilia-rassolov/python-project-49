#!/usr/bin/env python3

from brain_games.games.even import even_test


def main():
    print("Welcome to the Brain Games!")
    even_test()


if __name__ == '__main__':
    main()
