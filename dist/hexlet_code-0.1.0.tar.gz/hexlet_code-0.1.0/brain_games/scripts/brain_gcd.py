from brain_games.games import gcd
from brain_games.games import logic


def main():
    logic.game_make(gcd)


if __name__ == '__main__':
    main()
