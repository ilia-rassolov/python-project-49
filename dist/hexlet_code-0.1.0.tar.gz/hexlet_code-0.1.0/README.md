### Hexlet tests and linter status:
[![Actions Status](https://github.com/ilia-rassolov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ilia-rassolov/python-project-49/actions)
<a href="https://codeclimate.com/github/ilia-rassolov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f315eb1f909eb7b075f2/maintainability" /></a>
https://asciinema.org/a/xFrdfqMM2I9ZwvfPtZWXun5Yr
https://asciinema.org/connect/ed1314b2-9677-4826-a07b-826da30c8268
https://asciinema.org/a/RQGU14N3qpHawQ7JqwNVB7eXK

