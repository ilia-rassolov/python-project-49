### Hexlet tests and linter status:
[![Actions Status](https://github.com/ilia-rassolov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ilia-rassolov/python-project-49/actions)
<a href="https://codeclimate.com/github/ilia-rassolov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f315eb1f909eb7b075f2/maintainability" /></a>
