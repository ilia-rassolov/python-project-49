# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*'],
 'brain_games.games': ['.idea/.gitignore',
                       '.idea/.gitignore',
                       '.idea/.gitignore',
                       '.idea/.gitignore',
                       '.idea/.gitignore',
                       '.idea/games.iml',
                       '.idea/games.iml',
                       '.idea/games.iml',
                       '.idea/games.iml',
                       '.idea/games.iml',
                       '.idea/inspectionProfiles/*',
                       '.idea/misc.xml',
                       '.idea/misc.xml',
                       '.idea/misc.xml',
                       '.idea/misc.xml',
                       '.idea/misc.xml',
                       '.idea/modules.xml',
                       '.idea/modules.xml',
                       '.idea/modules.xml',
                       '.idea/modules.xml',
                       '.idea/modules.xml',
                       '.idea/vcs.xml',
                       '.idea/vcs.xml',
                       '.idea/vcs.xml',
                       '.idea/vcs.xml',
                       '.idea/vcs.xml']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'brain-games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ilia-rassolov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ilia-rassolov/python-project-49/actions)\n<a href="https://codeclimate.com/github/ilia-rassolov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f315eb1f909eb7b075f2/maintainability" /></a>\nhttps://asciinema.org/a/xFrdfqMM2I9ZwvfPtZWXun5Yr\nhttps://asciinema.org/connect/ed1314b2-9677-4826-a07b-826da30c8268\nhttps://asciinema.org/a/RQGU14N3qpHawQ7JqwNVB7eXK\nhttps://asciinema.org/a/Fjk5pYSHUWfk6ZEf0sfaiIZei\nhttps://asciinema.org/a/TWI6GTq3JiwSVxBJ3R9C9Wcq5\n',
    'author': 'Ilia Rassolov',
    'author_email': 'iliarassolov@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/ilia-rassolov/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
