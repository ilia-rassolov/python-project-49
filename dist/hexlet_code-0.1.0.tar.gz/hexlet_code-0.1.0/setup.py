# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ilia-rassolov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ilia-rassolov/python-project-49/actions)\n<a href="https://codeclimate.com/github/ilia-rassolov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f315eb1f909eb7b075f2/maintainability" /></a>\nhttps://asciinema.org/a/xFrdfqMM2I9ZwvfPtZWXun5Yr\n',
    'author': 'Ilia Rassolov',
    'author_email': 'iliarassolov@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
